"""Self-driving robotic race car controller demo."""

from racing import RobotCommand, RobotSensors

__author__: str = "730986400"

RACING_NAME: str = "Level 0"
RACING_COLOR: str = "#FEDD00"


def control(sensors: RobotSensors) -> RobotCommand:
    """A minimally viable self-driving controller using wall sensors."""
    throttle: float = 0.1
    steer: float = 0.0

    if sensors.wall_lidar.front_left_m < 4.0:
        steer = 1.0
    elif sensors.wall_lidar.front_right_m < 4.0:
        steer = -1.0
    else:
        steer = 0.0

    return RobotCommand(throttle=throttle, steer=steer)
